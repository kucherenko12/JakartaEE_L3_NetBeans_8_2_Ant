package com.example.jakartaee_l2.entities;

public enum Gender
{
    MALE,
    FEMALE
}
