package com.example.jakartaee_l2.web.servlet;

public class EditAnqueteServlet
{
    
}
