package com.example.jakartaee_l2.web;

import javax.ejb.Stateless;

@Stateless
public class EJBTest
{
    public String test()
    {
        return("do");
    }
}
